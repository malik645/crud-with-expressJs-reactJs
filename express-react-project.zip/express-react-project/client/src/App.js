import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import Crud from './components/Crud';

function App() {
  const [data, setData] = useState(null);
  const [username, setUsername] = useState('');
  
  const api_url = 'http://localhost:5000/'
  useEffect(() => {
    axios.get(api_url + 'api/data')
  .then(response => {
    console.log(response.data);
    setData(response.data);
  })
  .catch(error => {
    console.log(error);
  });
  //   fetch('http://localhost:5000/api/data')
  //     .then(res => res.json())
  //     .then(data => setData(data))
  //     .catch(err => console.log(err));
  }, []);
  const handleSubmit = (event) => {
    event.preventDefault();

    axios.post(api_url + 'api/data', {
        username: username
    })
    .then(response => {
        setUsername(response.data);
    })
    .catch(error => {
        console.log(error);
    });
 
};

  return (
    <div>
      {/* {data ? data.users.map((user, index)=>{
        return(
          <div key={index}>{user}</div>
        )
      }) : <p>Loading...</p>}
      <form onSubmit={handleSubmit}>
      <label>
        Username:
        <input type="text" onChange={event => setUsername(event.target.value)} />
      </label>
      <br />
      <button type="submit">Add User</button>
    </form> */}
    <Crud/>
    </div>
  );
}

export default App;
