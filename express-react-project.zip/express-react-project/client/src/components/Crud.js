import React,{useState, useEffect} from "react";
import axios from 'axios';
import "./Crud.css"
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import ReactLoading from 'react-loading';
import ClipLoader from "react-spinners/ClipLoader";

const override = {
  display: "block",
  margin: "0 auto",
  borderColor: "red",
};

function Crud({ balls, black }){
    const [students, setStudents] = useState([]);
    const [studentName, setStudentName] = useState();
    const [studentId, setStudentId] = useState();
    const [updateStudent, setUpdateStudent] = useState(false);
    const [showLoading, setShowLoading] = useState(false);
    let [loading, setLoading] = useState(true);
    let [color, setColor] = useState("#ffffff");

    const api_url = 'http://localhost:5000/'
    const addStudentItem = () => toast("Student Record Added");
    const deleteStudentItem = () => toast("Student Record Deleted");
    const updateStudentItem = () => toast("Student Record Updated");
    useEffect(() => {
        axios.get(api_url + 'api/crudData')
      .then(response => {
        console.log(response.data);
        setStudents(response.data.studentsList);
      })
      .catch(error => {
        console.log(error);
      });
      }, []);
      console.log(students);

    //   using then catch
    //   const deleteHandler=(id)=>{
    //     // console.log(id);
    //     // setStudents(students.filter((student)=> student.id !== id));
    //     axios.post(api_url + 'api/deleteData', {
    //         id
    //     })
    //     .then(response => {
    //         setStudents(response.data.studentsList)
    //     })
    //     .catch(error => {
    //         console.log(error);
    //     });

    //   }

    // using async await
    const deleteHandler=async (id)=>{
      deleteStudentItem();
        try {
            setShowLoading(true);
            let response = await axios.post(api_url + 'api/deleteData', {
                id
            })
            console.log(response);
            if(response.status){
              setShowLoading(false);
            }
            setStudents(response.data.studentsList)
        } catch (error) {
            console.log(error);
        }
    }

      const addHandler = (event) =>{
        event.preventDefault();
        addStudentItem();
        if (!studentName) {
            alert('All inputs are required')
            return
          }
          const student = {
            id: Math.floor(Math.random() * 100),
            name: studentName
        }
        axios.post(api_url + 'api/crudData', {
            students: student
        })
        .then(response => {
            setStudents(response.data.studentsList)
        })
        .catch(error => {
            console.log(error);
        });
        setStudentName('')
      }
      const updateHandler=(item)=>{
        setStudentId(item);
        setStudentName(item.name)
        setUpdateStudent(true)
      }
      const ctaHandler=()=>{
   
        updateStudentItem();
        const student = {
            id: studentId.id,
            name: studentName
        }
        const updatedStudents = students.map((item, index) => {
            console.log(studentId);
            if (item.id === studentId.id) {
              return student;
            } else {
              return item;
            }
          });
          console.log(updatedStudents);
          axios.post(api_url + 'api/updateData', {
            students: updatedStudents
        })
        .then(response => {
          console.log(response);
            setStudents(response.data.studentsList)
        })
        .catch(error => {
            console.log(error);
        });
        setStudentName('');
        setUpdateStudent(false);
      }
      console.log(studentName);
    return(
        <div className="crud-wrapper">
          <div className="header">
            <h1>Crud using Express Js and React Js</h1>
          </div>
          <div className="body">
          <input type="text" placeholder="Enter Name" value={studentName} onChange={(e)=>setStudentName(e.target.value)}/>
            {
                updateStudent? 
                <button className="btn-grad" onClick={ctaHandler}>Update</button>
                :
                <button className="btn-grad" onClick={addHandler}>Add Student</button>
            }
            <table>
                <tr>
                    <th>Id</th>
                    <th>Name</th>
                    <th>Actions</th>
                </tr>
                {
                    students.map((item, index)=>{
                        return(
                            <tr key={index}>
                                <td>{item.id}</td>
                                <td>{item.name}</td>
                                <td><img src={require("../images/delete.png")} alt="delete" onClick={()=>deleteHandler(item.id)}/></td>
                                <td><img src={require("../images/edit.png")} alt="edit" onClick={()=>updateHandler(item)}/></td>
              
                            </tr>
                        )
                    })
                }
            </table>
            <ToastContainer />
            {
              showLoading?
                  <ClipLoader
                    color={color}
                    loading={loading}
                    cssOverride={override}
                    size={50}
                    aria-label="RingLoader"
                    data-testid="RingLoader"
                  />
              :
              ''
            }
          </div>
        </div>
    );
}
export default Crud;