const express = require('express');
const app = express();
console.log(app);
const bodyParser = require('body-parser');

app.use(bodyParser.json());

app.use(express.json());

app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

// app.get('/api/data', (req, res) => {
//     res.json({users: ["userOne", "userTwo", "userThree", "userFour"] });
// });
let users = ["userOne", "userTwo", "userThree", "userFour"];
app.get('/api/data', (req, res) => {
    res.json({users: users });
});
app.post('/api/data', (req, res) => {
    users.push(req.body.username);
    res.json({users: users });
});
let studentsList = [
    {
        id:Math.floor(Math.random() * 100),
        name: 'Shadab',
    },
    {
        id:Math.floor(Math.random() * 100),
        name: 'Babar',
    }
];
app.get('/api/crudData', (req, res) => {
    res.json({studentsList: studentsList });
});
app.post('/api/crudData', (req, res) => {
    studentsList.push(req.body.students);
    res.json({studentsList: studentsList });
});
app.post('/api/deleteData', (req, res) => {
    const id = req.body.id
    // console.log('id', id)
    var index = studentsList.map(x => {
        return x.id;
      }).indexOf(id);
      studentsList.splice(index, 1)
    res.json({studentsList: studentsList });
});
app.post('/api/updateData', (req, res) => {
    // console.log(req.body.students);
    studentsList = req.body.students;
    res.json({studentsList: studentsList });
});
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server started on port ${PORT}`));
